# Video Downloader Backend

## Install
```
pip install -r requirements.txt
```

## Run
```
uvicorn main:app --host 0.0.0.0 --port 8000
```

## Test
```
http://localhost:8000/get_video?url=<INSTAGRAM_LINK>
```
