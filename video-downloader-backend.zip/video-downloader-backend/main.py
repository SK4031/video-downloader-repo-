from fastapi import FastAPI, Query
from fastapi.responses import JSONResponse
import requests
from bs4 import BeautifulSoup
import re

app = FastAPI()
HEADERS = {"User-Agent": "Mozilla/5.0"}

def extract_instagram(url: str):
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        soup = BeautifulSoup(r.text, "html.parser")
        meta = soup.find("meta", property="og:video")
        if meta and meta.get("content"):
            return meta["content"]
    except:
        pass
    return None

@app.get("/get_video")
def get_video(url: str = Query(...)):
    url_low = url.lower()
    if "instagram.com" in url_low:
        video_url = extract_instagram(url)
    else:
        return JSONResponse(status_code=400, content={"status":"failed","message":"Platform not supported yet."})
    
    if video_url:
        return {"status":"success","video_url":video_url}
    return JSONResponse(status_code=400, content={"status":"failed","message":"Could not extract video."})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
